curl -X POST https://c59da4db672d.ngrok-free.app/users/ \
  -H "Content-Type: application/json" \
  -d '{
    "first_name": "Akshay",
    "last_name": "Gupta",
    "timezone": "America/New_York",
    "email": "testuser@example.com",
    "phone_number": "+17204164661"
  }'
